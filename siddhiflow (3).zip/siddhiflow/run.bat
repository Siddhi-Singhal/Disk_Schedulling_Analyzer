@echo off
REM SiddhiFlow launcher for Windows. Only Python is required.
REM If gcc (MinGW) is installed, the fast C engine is built and used; otherwise the built-in Python engine is used.
cd /d "%~dp0"
where python >nul 2>nul || (echo Python not found. Install it from python.org and tick "Add Python to PATH". & pause & exit /b 1)
where gcc >nul 2>nul && (
  echo Building C engine...
  gcc -std=c11 -O2 -shared backend\algorithms.c backend\wasm_api.c -o backend\siddhiflow.dll
)
python server.py %*
pause
