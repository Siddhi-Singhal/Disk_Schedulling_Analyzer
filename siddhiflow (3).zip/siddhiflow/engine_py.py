"""Pure-Python port of backend/algorithms.c + wasm_api.c.
Used automatically when the C library (siddhiflow.dll / libsiddhiflow.so) is not available,
so the project runs on Windows with only Python installed. Same JSON output as the C engine."""
import re

NAMES = ["FCFS", "SSTF", "SCAN", "C-SCAN", "LOOK", "C-LOOK"]
_TOKEN = re.compile(r"^[+-]?\d+$")


def _parse(s):
    out = []
    for t in re.split(r"[,\s]+", s.strip()):
        if not t:
            continue
        if not _TOKEN.match(t):
            return None
        v = int(t)
        if v < -1000000 or v > 1000000 or len(out) >= 100000:
            return None
        out.append(v)
    return out


def _sweep(r, head, lo, hi, d, mode):
    s = sorted(r)
    L = [x for x in s if x < head]
    H = [x for x in s if x >= head]
    seq = []  # (pos, served)
    cur = head
    def go(pos, served):
        nonlocal cur
        seq.append((pos, served)); cur = pos
    if d:
        for x in H: go(x, 1)
        if mode == 0:
            if cur != hi: go(hi, 0)
            for x in reversed(L): go(x, 1)
        elif mode == 1:
            if cur != hi: go(hi, 0)
            if L:
                go(lo, 0)
                for x in L: go(x, 1)
        elif mode == 2:
            for x in reversed(L): go(x, 1)
        else:
            for x in L: go(x, 1)
    else:
        for x in reversed(L): go(x, 1)
        if mode == 0:
            if cur != lo: go(lo, 0)
            for x in H: go(x, 1)
        elif mode == 1:
            if cur != lo: go(lo, 0)
            if H:
                go(hi, 0)
                for x in reversed(H): go(x, 1)
        elif mode == 2:
            for x in H: go(x, 1)
        else:
            for x in reversed(H): go(x, 1)
    return seq


def _order(alg, r, head, lo, hi, d):
    if alg == 0:
        return [(x, 1) for x in r]
    if alg == 1:
        left, cur, seq = list(r), head, []
        while left:
            b = min(range(len(left)), key=lambda i: (abs(left[i] - cur), i))
            cur = left.pop(b); seq.append((cur, 1))
        return seq
    return _sweep(r, head, lo, hi, d, alg - 2)


def run(alg, reqs, head, lo, hi, d):
    if alg < 0 or alg >= 6:
        return {"error": "Unknown algorithm"}
    r = _parse(reqs or "")
    if not r:
        return {"error": "Request list is empty or contains an invalid value"}
    if lo >= hi or head < lo or head > hi:
        return {"error": "Invalid cylinder range or head position"}
    if any(x < lo or x > hi for x in r):
        return {"error": "A request is outside the cylinder range"}
    steps, cur, total = [], head, 0
    for pos, served in _order(alg, r, head, lo, hi, 1 if d else 0):
        dist = abs(pos - cur); total += dist; cur = pos
        steps.append({"p": pos, "s": dist, "v": served})
    return {"name": NAMES[alg], "id": alg, "head": head, "min": lo, "max": hi,
            "total": total, "avg": round(total / len(r), 4), "n": len(r), "steps": steps}
